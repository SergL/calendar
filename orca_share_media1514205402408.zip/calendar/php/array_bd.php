﻿<?

//массив типов календарей
$calselics['милонги (в городе)']='milonga';
$calselics['фестиваль (расписание)']='tango_event';
$calselics['клуб (школа)']='shool';

//массив типов календарей
$calselval[ru]['milonga']='милонги в городе';
$calselval[ru]['tango_event']='фестиваль (расписание)';
$calselval[ru]['shool']='клуб (школа)';

//массив типов календарей
$calselval[ua]['milonga']='милонги в місті';
$calselval[ua]['tango_event']='фестивалі (розклад)';
$calselval[ua]['shool']='клуб (школа)';

//массив типов календарей
$calselval[en]['milonga']='milonga in city';
$calselval[en]['tango_event']='festival (schedule)';
$calselval[en]['shool']='shool';

?>