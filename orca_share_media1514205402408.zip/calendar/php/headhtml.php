<head>
<?
echo "
	 <title>
	   $title</title>";
?>
	
	 <link rel='shortcut icon' href='img/icon.png' type='image/png'>
</head>
	 <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	 <?php
include_once('poisk.html');

?>